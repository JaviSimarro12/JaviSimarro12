<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: index.php');
    exit;
}
include("conexion.php");
    $con=conectar();
    $id=$_POST['ID'];
    $marca=$_POST['marca'];
    $modelo=$_POST['modelo'];
    $precio=$_POST['precio'];
        $sql="UPDATE mesas SET  marca='$marca',modelo='$modelo',precio='$precio' WHERE ID='$id'";
        $query=mysqli_query($con,$sql);
if($query){
    Header("Location: principal.php");
}
?>