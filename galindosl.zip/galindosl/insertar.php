<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: indexs.php');
    exit;
}
include("conexion.php");
    $con=conectar();
    $id=$_POST['ID'];
    $marca=$_POST['marca'];
    $modelo=$_POST['modelo'];
    $precio=$_POST['precio'];
    $sql="INSERT INTO mesas VALUES('$id','$marca','$modelo','$precio')";
    $query= mysqli_query($con,$sql);
if($query){
    Header("Location: principal.php");
}else {
}
?>