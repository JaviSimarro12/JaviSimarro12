<?php
function conectar(){
    $host="localhost";
    $usuario="root";
    $contrasena="";
    $bd="galindosl";
    $con=mysqli_connect($host,$usuario,$contrasena);
    mysqli_select_db($con,$bd);
return $con;
}
?>