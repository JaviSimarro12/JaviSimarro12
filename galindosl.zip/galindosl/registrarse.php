<?php 

//Con esto conseguiremos redirigir a la pagina del index si el usuario no se ha logeado para que se logee y no pueda editar sin registrarse.
session_start();



//Conexión a la base de datos.
    include("conexion.php");
    $con=conectar();


$usuario=$_POST["usuario"];
$contra=$_POST["contra"];

$sql="SELECT * FROM usuarios";
$query=mysqli_query($con,$sql);


?>

<!DOCTYPE html>

    <head>
        <title>Registrarse</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <title>Actualizar</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        
    </head>
    <body style="background-color:lightgreen;">
        <div class="container mt-5">
        <form action="registrarse2.php" method="POST">
                    
    <!-- Tablas para rellenar los datos del nuevo usuario. -->
            
            <input type="text" class="form-control mb-3" name="usuario" placeholder="Usuario" >
            <input type="text" class="form-control mb-3" name="contra" placeholder="Contra" >
            <input type="submit" class="btn btn-primary btn-block" value="Registrar">
    </form>
                    
        </div>
    </body>
</html>