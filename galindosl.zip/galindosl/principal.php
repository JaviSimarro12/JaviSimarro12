<?php 
session_start();
  if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
      header('Location: index.php');
      exit;
  }
    include("conexion.php");
    $con=conectar();
    $sql= "SELECT * FROM mesas";
    $query=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title> GalindoSL</title>
        <a name="cerrar" id="cerrar" class="btn btn-primary" href="cerrar.php" role="button">Cerrar Sesión</a>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
        <style>
                h1 {text-align: center;}
        </style>
    </head>
    <body style="background-color:lightwhite;">
   <h1><b>GalindoSL</b></h1>
            <div class="container mt-5">
            <div class="row"> 
            <div class="col-md-3">
                <h1>Nueva Mesa</h1>
                    <form action="insertar.php" method="POST">

                        <input type="text" required readonly class="form-control mb-3" name="id" placeholder="Id">
                        <input type="text" class="form-control mb-3" name="marca" placeholder="Marca">
                        <input type="text" class="form-control mb-3" name="modelo" placeholder="Modelo">
                        <input type="text" class="form-control mb-3" name="precio" placeholder="Precio">            
                        <input type="submit" class="btn btn-primary">
                    </form>
            </div>
            <div class="col-md-8">
                <h1>Mesas En Stock</h1>
            <table class="table" >
                <thead class="table-success table-striped" >
                    <tr>
                    <th>ID</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Precio</th>
                    <th></th>
                    <th></th>
                    </tr>
                </thead>
    <tbody>
            <?php
                while($row=mysqli_fetch_array($query)){
            ?>
                <tr>
                    <th><?php  echo $row['ID']?></th>
                    <th><?php  echo $row['Marca']?></th>
                    <th><?php  echo $row['Modelo']?></th>
                    <th><?php  echo $row['Precio']?></th>   
                    <th><a href="modificar.php?ID=<?php echo $row['ID'] ?>" class="btn btn-info">Modificar</a></th>
                    <th><a href="eliminar.php?ID=<?php echo $row['ID'] ?>" class="btn btn-danger">Eliminar</a></th>                                        
                </tr>
            <?php 
                }
            ?>
    </tbody>
        </table>
        </div>
        </div>  
        </div>
    </body>
</html>