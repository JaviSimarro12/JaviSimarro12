<?php
session_start();
include("conexion.php");
    $con=conectar();
    $usuario=$_POST['usuario'];
    $contra=$_POST['contra'];
        $sql="INSERT INTO usuarios VALUES('$usuario','$contra')";
        $query= mysqli_query($con,$sql);
        $query=mysqli_query($con,$sql);
if($query){
    Header("Location: index.php");
}
?>