<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: index.php');
    exit;
}
include("conexion.php");
    $con=conectar();
    $id=$_GET['ID'];
    $sql="DELETE FROM mesas  WHERE ID='$id'";
    $query=mysqli_query($con,$sql);
if($query){
    Header("Location: principal.php");
    }
?>